const mongoose = require("mongoose");

const ContentSchema = new mongoose.Schema({
  title: String,
  description: String,
  status: {
    type: String,
    default: "Pending"
  },
  authorId: mongoose.Schema.Types.ObjectId,
  region: String,
  projectId: String,
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("Content", ContentSchema);
