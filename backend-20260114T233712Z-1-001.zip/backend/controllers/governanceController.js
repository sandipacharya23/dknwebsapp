const Content = require("../models/Content");

exports.approveContent = async (req, res) => {
  const content = await Content.findById(req.params.id);
  content.status = "Published";
  await content.save();
  res.json(content);
};
