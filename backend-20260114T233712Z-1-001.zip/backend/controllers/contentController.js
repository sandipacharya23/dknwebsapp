// src/controllers/contentController.js
const Content = require("../models/Content");
const Tag = require("../models/Tag");
const Project = require("../models/Project");

exports.createContent = async (req, res) => {
  try {
    const { title, description, tags, projectId } = req.body;
    const file = req.file;

    if (!file) {
      return res.status(400).json({ message: "File is required" });
    }

    // Business Rule: must have at least one tag or project
    const tagList = tags ? tags.split(",").map(t => t.trim()).filter(t => t) : [];
    if (tagList.length === 0 && !projectId) {
      return res.status(400).json({ message: "At least one tag or project is required" });
    }

    // Create or find tags
    const tagIds = [];
    for (const name of tagList) {
      let tag = await Tag.findOne({ name });
      if (!tag) tag = await Tag.create({ name });
      tagIds.push(tag._id);
    }

    // Find project (optional)
    let project = null;
    if (projectId) {
      project = await Project.findById(projectId);
      if (!project) {
        return res.status(400).json({ message: "Project not found" });
      }
    }

    // Create content
    const content = await Content.create({
      title,
      description,
      filePath: file.path,
      status: "UNDER_REVIEW",
      author: req.user._id,
      region: req.user.region,
      tags: tagIds,
      project: project ? project._id : undefined,
      auditLog: [{ action: "UPLOADED", by: req.user._id }]
    });

    res.status(201).json(content);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getAllContent = async (req, res) => {
  try {
    const contents = await Content.find().populate("author tags project");
    res.json(contents);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
