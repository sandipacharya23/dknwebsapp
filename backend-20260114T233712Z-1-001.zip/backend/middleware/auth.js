module.exports = (req, res, next) => {
  req.user = { role: "Senior Consultant" };
  next();
};
