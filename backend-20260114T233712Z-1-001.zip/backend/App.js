const express = require("express");
const connectDB = require("./config/db");
require("dotenv").config();

const app = express();
connectDB();

app.use(express.json());

app.use("/api/content", require("./routes/contentRoutes"));
app.use("/api/governance", require("./routes/governanceRoutes"));

app.listen(3000, () => console.log("Server running on port 3000"));
