const { auth } = require("../middleware/auth");
const multer = require("multer");
const { createContent, getAllContent } = require("../controllers/contentController");

const router = require("express").Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) =>
    cb(null, Date.now() + "-" + Math.round(Math.random() * 1e9) + require("path").extname(file.originalname)),
});
const upload = multer({ storage });

router.post("/", auth, upload.single("file"), createContent);
router.get("/", auth, getAllContent);

module.exports = router;
