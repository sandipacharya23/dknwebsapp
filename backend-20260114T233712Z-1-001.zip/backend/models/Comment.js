const mongoose = require("mongoose");

const CommentSchema = new mongoose.Schema({
  text: String,
  authorId: mongoose.Schema.Types.ObjectId,
  contentId: mongoose.Schema.Types.ObjectId,
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("Comment", CommentSchema);
