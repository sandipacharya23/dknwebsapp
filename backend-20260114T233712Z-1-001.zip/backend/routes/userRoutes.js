const express = require("express");
const router = express.Router();
const { approveContent } = require("../controllers/governanceController");

router.put("/Approve/:id", approveContent);

module.exports = router;
