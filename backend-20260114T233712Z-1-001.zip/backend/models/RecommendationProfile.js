const mongoose = require("mongoose");

const RecommendationProfileSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },
  preferenceVector: {
    type: [String],
    default: []
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model(
  "RecommendationProfile",
  RecommendationProfileSchema
);
