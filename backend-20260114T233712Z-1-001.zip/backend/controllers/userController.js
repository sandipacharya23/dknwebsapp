const User = require("../models/User");

/**
 * Create a new user (simulates HR/SSO sync)
 */
exports.createUser = async (req, res) => {
  try {
    const user = await User.create(req.body);
    res.status(201).json(user);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

/**
 * Get all users
 */
exports.getUsers = async (req, res) => {
  const users = await User.find();
  res.json(users);
};

/**
 * Get user by ID
 */
exports.getUserById = async (req, res) => {
  const user = await User.findById(req.params.id);
  res.json(user);
};
