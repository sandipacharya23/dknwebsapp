// src/services/contentService.js
const Content = require("../models/Content");
const Tag = require("../models/Tag");
const Project = require("../models/Project");

async function createContent({ title, description, tags, projectId, filePath, author, region }) {
  if ((!tags || tags.length === 0) && !projectId) {
    throw new Error("Content requires at least one tag or a project");
  }

  let tagIds = [];
  if (tags && tags.length > 0) {
    for (const name of tags) {
      const trimmed = name.trim();
      if (!trimmed) continue;
      let tag = await Tag.findOne({ name: trimmed });
      if (!tag) tag = await Tag.create({ name: trimmed });
      tagIds.push(tag._id);
    }
  }

  let project = null;
  if (projectId) {
    project = await Project.findById(projectId);
  }

  const content = await Content.create({
    title,
    description,
    status: "UNDER_REVIEW",
    author,
    region,
    project: project ? project._id : undefined,
    tags: tagIds,
    filePath,
    auditLog: [{ action: "UPLOADED", by: author }],
  });

  return content;
}

async function getContentById(id) {
  return Content.findById(id).populate("author tags project");
}

module.exports = { createContent, getContentById };
